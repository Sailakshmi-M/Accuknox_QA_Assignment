from playwright.sync_api import Page

class AdminPage:
    def __init__(self, page: Page):
        self.page = page
        self.admin_tab = "a[href*='admin']"
        self.add_button = "button:has-text('Add')"
        self.username_field = "input[placeholder='Type for hints...']"
        self.save_button = "button:has-text('Save')"
        self.search_field = "input[placeholder='Search']"
        self.delete_icon = "i.bi-trash"
        self.confirm_delete = "button:has-text('Yes, Delete')"

    def navigate_to_admin(self):
        self.page.wait_for_selector(self.admin_tab)
        self.page.click(self.admin_tab)

    def add_user(self, username):
        self.page.click(self.add_button)
        self.page.fill(self.username_field, username)
        self.page.click(self.save_button)

    def search_user(self, username):
        self.page.fill(self.search_field, username)
        self.page.press(self.search_field, "Enter")

    def delete_user(self):
        self.page.click(self.delete_icon)
        self.page.click(self.confirm_delete)
