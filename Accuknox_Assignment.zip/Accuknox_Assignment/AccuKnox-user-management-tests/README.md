# AccuKnox User Management Tests

## 🔧 Setup

```bash
pip install -r requirements.txt
playwright install
```

## ▶️ Run the Tests

```bash
pytest tests/test_user_management.py
```

## 📦 Tech Stack

- Python
- Playwright
- Page Object Model
