from playwright.sync_api import sync_playwright
from pages.login_page import LoginPage
from pages.admin_page import AdminPage

def test_user_management_flow():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()

        login_page = LoginPage(page)
        login_page.login("Admin", "admin123")

        admin_page = AdminPage(page)
        admin_page.navigate_to_admin()
        admin_page.add_user("testuser123")
        admin_page.search_user("testuser123")
        admin_page.delete_user()

        browser.close()
