import psutil
import logging

logging.basicConfig(filename="system_health.log", level=logging.INFO)

CPU_THRESHOLD = 80
MEM_THRESHOLD = 80
DISK_THRESHOLD = 80

def check_health():
    cpu = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory().percent
    disk = psutil.disk_usage("/").percent

    logging.info(f"CPU: {cpu}%, Memory: {memory}%, Disk: {disk}%")

    if cpu > CPU_THRESHOLD:
        print(f"ALERT: High CPU Usage: {cpu}%")
    if memory > MEM_THRESHOLD:
        print(f"ALERT: High Memory Usage: {memory}%")
    if disk > DISK_THRESHOLD:
        print(f"ALERT: High Disk Usage: {disk}%")

if __name__ == "__main__":
    check_health()
