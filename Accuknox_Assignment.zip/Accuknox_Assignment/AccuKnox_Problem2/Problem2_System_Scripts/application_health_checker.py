import requests

URL = "https://opensource-demo.orangehrmlive.com/"

def check_application_status():
    try:
        response = requests.get(URL, timeout=5)
        if response.status_code == 200:
            print(f"Application is UP. Status Code: {response.status_code}")
        else:
            print(f"Application is DOWN. Status Code: {response.status_code}")
    except requests.RequestException as e:
        print(f"Application is DOWN. Error: {e}")

if __name__ == "__main__":
    check_application_status()
