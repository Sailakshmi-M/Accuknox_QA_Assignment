# Problem 2: System Scripting with Python

## Objective 1: System Health Monitoring
This script monitors:
- CPU usage
- Memory usage
- Disk usage

If thresholds are crossed, alerts are printed and logs are written to `system_health.log`.

Run:
```bash
python3 system_health_monitor.py
```

## Objective 4: Application Health Checker
Checks the status of an application via HTTP GET.

Run:
```bash
python3 application_health_checker.py
```
